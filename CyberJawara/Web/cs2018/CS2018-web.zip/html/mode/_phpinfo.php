<?php

$rets = function(){
	phpinfo();
};

$deploy = false;