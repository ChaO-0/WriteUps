package com.hipstartup.substringcounter;

public class UnsupportedCharacterException extends RuntimeException {
}
