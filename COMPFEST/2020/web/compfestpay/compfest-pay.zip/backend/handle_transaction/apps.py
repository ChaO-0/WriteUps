from django.apps import AppConfig


class HandleTransaksiConfig(AppConfig):
    name = 'handle_transaction'
