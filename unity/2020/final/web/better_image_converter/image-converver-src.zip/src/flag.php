<?php

$flag = "UNITY2020{<REDACTED>}";
