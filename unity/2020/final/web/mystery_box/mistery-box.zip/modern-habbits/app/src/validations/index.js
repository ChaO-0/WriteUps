module.exports.boxValidations = require("./box.validation");
