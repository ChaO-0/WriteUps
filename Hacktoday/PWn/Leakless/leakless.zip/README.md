# leaklees
no `view()`, no surrender!