# ezrop

key is the new val. yo.

```
nc not.codepwnda.id 30000
```

